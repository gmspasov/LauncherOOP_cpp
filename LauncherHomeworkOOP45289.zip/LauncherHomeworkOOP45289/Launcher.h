#ifndef LAUNCHER_H
#define LAUNCHER_H

#include "LauncherItem.h"
#include <iostream>


/* class representing the screen of a mobile phone where shortcuts to apps, folders and others can be put*/

class Launcher
{
public:
    /** Default constructor */
    Launcher();

    /**Constructor with parameters*/
    Launcher(int length,int width);

    /**kind of copy constructor*/
    Launcher(LauncherItem*** items,bool** is_taken,int length,int width);

    /** Destructor */
    virtual ~Launcher();

    /** Copy constructor
     *  \param other Object to copy from
     */
    Launcher(const Launcher& other);

    /** Assignment operator
     *  \param other Object to assign from
     *  \return A reference to this
     */
    Launcher& operator=(const Launcher& other);

    /** Adds the element to the certain position on the screen- if it is taken- it puts the element on the first free position
    * up to down and left to right
    */
    void add_element( LauncherItem& element,int length,int width);

    /** Removes the element from the certain position */
    void remove_element(int length,int width);

    /** Moves the element to the new position. If there is already another movable elements- it swaps their places */
    void move_element(int original_length,int original_width,int new_length,int new_width);

    /** Clears the screen */
    void clear() const;

    /** prints the names and position of each element of the screen, if there is no element- it writes Empty */
    friend ostream& operator<< (ostream& stream, const Launcher& thiss);

    /** copies items to the given screen kind of assignment operator*/
    void copy_items(LauncherItem*** items,bool** is_taken,int length,int width);

    /** returns if on the given position is an element */
    bool check_is_taken(int length,int width) const;

    /** \return length */
    int Get_length() const;

    /** \return width */
    int Get_width() const;

    /** Returns the title of the element on this position */
    char* Get_items_title(int length,int width) const;

    /** Returns if the screen is empty */
    bool check_is_empty();

protected:

private:
    LauncherItem*** items; //!< Member variable "items"
    int length; //!< Member variable "length"
    int width; //!< Member variable "width"
    bool ** is_taken; //!< Member variable "is_taken"
    bool is_empty; //!< Member variable "is_empty"
};

#endif // LAUNCHER_H
