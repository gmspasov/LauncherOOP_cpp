#include "MobileApp.h"
#include "LauncherItem.h"
#include "cassert"
#include "cstring"
#include <iostream>

MobileApp::MobileApp(char* new_title)
{
    Set_title(new_title);
}

void MobileApp:: Set_title(char* new_title)
{
    if(new_title!=NULL)
    {
        title=new char [strlen(new_title)+1];
        strcpy(title,new_title);
    }
}

MobileApp::MobileApp()
{
    /** default title is set*/
    Set_title("New Mobile Application");
}

MobileApp::~MobileApp()
{
    delete[] title;
}

MobileApp::MobileApp(const MobileApp& other)
{
    assert(other.title!=NULL);
    Set_title(other.title);
}

MobileApp& MobileApp::operator=(const MobileApp& rhs)
{
    if (this == &rhs)
        return *this; // handle self assignment
    assert(rhs.title!=NULL);
    Set_title(rhs.title);
    return *this;
}

bool MobileApp:: canMove() const
{
    return true;
}
