#include "Folder.h"
#include "LauncherItem.h"
#include "assert.h"
#include "cstring"

#include "Launcher.h"
#include "LauncherItem.h"

Folder::Folder(const Launcher& l)
{
    launch=new Launcher();
    *launch=l;
    Set_title();
}

void Folder:: Set_title()
{
    title=new char[2];
    strcpy(title,"");
    for(int i=0; i<launch->Get_length(); ++i)
    {
        for(int j=0; j<launch->Get_width(); ++j)
        {
            if(launch->check_is_taken(i,j))
            {
                /**if it is an element in the cell, its name is concatenated */
                strcat(title,launch->Get_items_title(i,j));
                strcat(title,", ");
            }
        }
    }
}

Folder::Folder()
{
    Set_title("Empty Folder");
    launch=new Launcher();
}

Folder::Folder(LauncherItem*** items,bool** is,int length,int width)
{
    launch= new Launcher(items,is,length,width);
    Set_title();
}
Folder::Folder(int l, int w)
{
    launch=new Launcher(l,w);
}

Folder::~Folder()
{
    deleteTitle();
    delete launch;
}

void Folder::clear()
{
    launch->clear();
    Set_title("Empty folder");
}

Folder::Folder(const Folder& other)
{
    launch=new Launcher();
    *launch=*(other.launch);
    Set_title();
}

Folder& Folder::operator=(const Folder& rhs)
{
    if (this == &rhs)
        return *this; // handle self assignment
    *launch=*(rhs.launch);
    Set_title();
    return *this;
}

void Folder:: Set_title(char* new_title)
{
    title=new char [strlen("Empty folder")+1];
    strcpy(title,"Empty folder");
}

void Folder::add_element( LauncherItem& elem,int l, int w)
{
    launch->add_element(elem,l,w);
    Set_title();
}

void Folder::remove_element(int l,int w)
{
    launch->remove_element(l,w);
    Set_title();
}

void Folder:: copy_items(LauncherItem*** new_items,bool ** is, int l,int w)
{
    launch->copy_items(new_items,is,l,w);
}
