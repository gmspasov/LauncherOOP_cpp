#include "Launcher.h"
#include "LauncherItem.h"


Launcher::Launcher()
{
    length=2;
    width=2;
    items=new LauncherItem**[2];
    for(int i=0; i<2; ++i)
    {
        items[i]=new LauncherItem*[2];
    }
    is_empty=1;
}

Launcher::Launcher(int len,int wid)
{
    if(len<=0 || wid<=0)
    {
        len=2;
        wid=len;
        cout<<"Invalid values of length or/and width. Default values of 2 have been set."<<endl;
    }

    /** creates the matrix*/
    is_taken=new bool* [len];
    length=len;
    width=wid;
    items=new LauncherItem**[len];
    for(int i=0; i<len; ++i)
    {
        is_taken[i]=new bool [wid];
        items[i]=new LauncherItem* [wid];
        for(int j=0; j<wid; ++j)
        {
            is_taken[i][j]=0;
        }
    }
    is_empty=1;
}

Launcher::Launcher(LauncherItem*** it,bool** is,int len, int wid)
{
    is_empty=1;
    if(len<=0 || wid<=0)
    {
        len=2;
        wid=len;
        cout<<"Invalid values of length or/and width. Default values of 2 have been set."<<endl;
    }

    /** creates the matrix and fill it*/
    is_taken=new bool* [len];
    length=len;
    width=wid;
    items=new LauncherItem**[len];
    for(int i=0; i<len; ++i)
    {
        is_taken[i]=new bool [wid];
        items[i]=new LauncherItem* [wid];
        for(int j=0; j<wid; ++j)
        {
            if(!is[i][j])
            {
                is_taken[i][j]=0;
            }

            else
            {
                is_taken[i][j]=1;
                is_empty=0;
            }
            items[i][j]=it[i][j];
        }
    }
}

void Launcher::add_element( LauncherItem& it, int l, int w)
{
    if(l>length||w>width||l<1||w<1)
    {
        cout<<"Couldn't add the element. There is no such position on the screen!"<<endl;
    }
    else
    {
        if(!is_taken[l-1][w-1])
        {
            items[l-1][w-1] = &it;
            is_taken[l-1][w-1]=1;
            is_empty=0;
        }
        else
        {
            int i=0;
            int j=0;
            while(i<length-1&&is_taken[i][j])
            {
                j=0;
                ++i;
                while(j<width-1&&is_taken[i][j])
                {
                    ++j;
                }
            }
            if(!is_taken[i][j])
            {
                items[i][j]=&it;
                is_taken[i][j]=1;
                is_empty=0;
                cout<<"The place is already taken. So the element will be added on position ["<<i<<","<<j<<"] ."<<endl;
            }
            else
            {
                cout<<"The screen is full. The item cannot be added. "<<endl;
            }
        }
    }
}

void Launcher::remove_element(int l, int w)
{
    if(l>=length||w>=width||l<1||w<1)
    {
        cout<<"Couldn't remove the element. There is no such position on the screen!"<<endl;
    }
    else
    {
        if(is_taken[l-1][w-1]&&items[l-1][w-1]->canMove())
        {
            items[l-1][w-1]=NULL;
            is_taken[l-1][w-1]=0;
            is_empty=check_is_empty();

        }
        else
        {
            cout<<"There is no such element or the element of the position cannot be moved. "<<endl;
        }
    }
}

bool Launcher::check_is_empty()
{

    for(int i =0; i<length; ++i)
    {
        for(int j=0; j<width; ++j)
        {
            if(is_taken[i][j])
            {
                is_empty=0;
                return false;
            }

        }
    }
    is_empty=1;
    return is_empty;
}

void Launcher::move_element(int or_l, int or_w, int new_l, int new_w)
{
    if(or_l>length||or_w>width||new_l>length||new_w>width||or_l<1||or_w<1||new_l<1||new_w<1)
    {
        cout<<"Couldn't move the element. There is no such position on the screen!"<<endl;
    }
    else
    {
        if(((is_taken[or_l-1][or_w-1])&&(items[or_l-1][or_w-1]->canMove())))
        {
            if(!is_taken[new_l-1][new_w-1])
            {
                /** moves the element to the new position that is free*/
                items[new_l-1][new_w-1]= items[or_l-1][or_w-1];
                items[or_l-1][or_w-1]=NULL;
                is_taken[or_l-1][or_w-1]=0;
                is_taken[new_l-1][new_w-1]=1;
            }
            else
            {
                if(items[new_l-1][new_w-1]->canMove())
                {
                /** swaps the elements*/
                    LauncherItem * temp;
                    temp= items[or_l-1][or_w-1];
                    items[or_l-1][or_w-1]=items[new_l-1][new_w-1];
                    items[new_l-1][new_w-1]=temp;
                    delete temp;
                }
                else
                {
                    cout<<"The object on position [" <<new_l <<","<<new_w<<"] is not movable."<<endl;
                }
            }
        }
        else
        {
            cout<<"Cannot move the element."<<endl;
        }
    }
}

void Launcher::clear() const
{
    if(!is_empty)
    {
        for(int i=0; i<length; ++i)
        {
            for(int j=0; j<width; ++j)
            {
                is_taken[i][j]=0;
                items[i][j]=NULL;
            }
        }
    }
}
ostream& operator<< (ostream& output,const Launcher& l)
{

    output<<endl<<endl<<endl<<"             -----------Printing the screen of the phone: ----------------             "
        <<endl<<endl<<endl;;


    for(int i=0; i<l.length; ++i)
    {
        for(int j=0; j<l.width; ++j)
        {
            if(l.is_taken[i][j])
            {
                output<<l.items[i][j]->Get_title()<<" is on position ["<<i+1<<","<<j+1<<"] "<<endl;
            }
            else
            {
                output<<"Empty cell on position ["<<i+1<<","<<j+1<<"] "<<endl;
            }
        }
    }
    return output;
}

Launcher::~Launcher()
{
    if(!is_empty)
    {
        for(int i=0; i<length; ++i)
        {
            delete[] items[i];
        }
        delete [] items;
    }
}

Launcher::Launcher(const Launcher& other)
{
    copy_items(other.items,other.is_taken,other.length,other.width);
}

Launcher& Launcher::operator=(const Launcher& rhs)
{
    if (this == &rhs)
        return *this; // handle self assignment
    else
    {

        if(rhs.is_empty)
        {
            this->clear();
            return *this;
        }
        this->copy_items(rhs.items,rhs.is_taken,rhs.length,rhs.width);
        return *this;
    }
}

void Launcher::copy_items(LauncherItem*** it,bool** is,int len,int wid)
{
    if(is_empty==0)
    {
        /**deletes if there are some elements*/

        for(int i=0; i<length; ++i)
        {
            delete[] items[i];
        }
        delete[] items;

    }

    if(len<=0 || wid<=0)
    {
        len=2;
        wid=len;
        cout<<"Invalid values of length or/and width. Default values of 2 have been set."<<endl;
    }

    /** creates the matrix and fill it*/
    is_taken=new bool* [len];
    length=len;
    width=wid;
    items=new LauncherItem**[len];
    for(int i=0; i<len; ++i)
    {
        is_taken[i]=new bool [wid];
        items[i]=new LauncherItem* [wid];
        for(int j=0; j<wid; ++j)
        {
            if(!is[i][j])
            {
                is_taken[i][j]=0;
            }
            else
            {

                is_taken[i][j]=1;
                is_empty=1;
            }
            items[i][j]=it[i][j];
        }
    }

    check_is_empty();
}
bool Launcher::check_is_taken(int i, int j) const
{
    if(i<0||j<0||i>length||j>width)
    {
        cout<<"Wrong position returns default false."<<endl;
        return false;
    }
    if(is_empty)
    {
        return 0;
    }
    else
    {
        return is_taken[i][j];
    }
}

int Launcher::Get_length() const
{
    return length;
}

int Launcher::Get_width() const
{
    return width;
}

char* Launcher::Get_items_title(int i, int j) const
{
    if(i<0||j<0||i>length||j>width||!is_taken[i][j])
    {
        return "Empty or invalid position";
    }
    return items[i][j]->Get_title();
}


