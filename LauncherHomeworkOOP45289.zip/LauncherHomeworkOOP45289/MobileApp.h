#ifndef MOBILEAPP_H
#define MOBILEAPP_H

#include "LauncherItem.h"

//class representing a shortcut to a mobile app that can be put on a mobile phone screen

class MobileApp : public LauncherItem
{
    public:
        /** Default constructor */
        MobileApp();

        /**Constructor with parameters
        * \param title of the app
        */
        MobileApp(char* title);

        /** Destructor */
        virtual ~MobileApp();

        /** Copy constructor
         *  \param other Object to copy from
         */
        MobileApp(const MobileApp& other);

        /** Assignment operator
         *  \param other Object to assign from
         *  \return A reference to this
         */
        MobileApp& operator=(const MobileApp& other);

        /** sets the title of the app- from base class*/
        void Set_title(char* title);

        /** boolean function that returns if the object is movable*/
        bool canMove() const;

        /**returns the title of the app - from base class*/
        void Get_title();


    protected:

    private:
};

#endif // MOBILEAPP_H
