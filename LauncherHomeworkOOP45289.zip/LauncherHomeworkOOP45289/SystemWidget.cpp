#include "SystemWidget.h"
#include "LauncherItem.h"
#include "cassert"
#include "cstring"

SystemWidget::SystemWidget()
{
    Set_title("System Widget");
}

SystemWidget::~SystemWidget()
{
delete[] title;
}

bool SystemWidget::canMove() const{
return false;
}

void SystemWidget:: Set_title(char* new_title)
{
    /** new_title is ignored*/

    title=new char [strlen("System Widget")+1];
    strcpy(title,"System Widget");
}


SystemWidget& SystemWidget:: operator=(const SystemWidget& rhs)
{
    return *this;
}

