#ifndef SYSTEMWIDGET_H
#define SYSTEMWIDGET_H

#include "LauncherItem.h"


class SystemWidget : public LauncherItem
{
    public:
        /** Default constructor */
        SystemWidget();

        /** Default destructor */
        virtual ~SystemWidget();

        /**sets default title "System Widget"-from base class */
        void Set_title(char*);

        /** boolean function that returns if the object is movable*/
        bool canMove () const;

         /** Assignment operator
         *  \param other Object to assign from
         *  \return A reference to this
         */
        SystemWidget& operator=(const SystemWidget& other);


    protected:

    private:
};

#endif // SYSTEMWIDGET_H
