#include <iostream>
#include "MobileApp.h"
#include "LauncherItem.h"
#include "Folder.h"
#include "SystemWidget.h"
#include "Launcher.h"

using namespace std;

int main()
{
   Launcher launch (6,6); //phone screen

   //creating elements
   MobileApp abr ("Angry Birds Rio") ;

   MobileApp cb ("Chess and Backgammon");

   MobileApp gm("Google Maps") ;

   SystemWidget s;

   SystemWidget f ;

   SystemWidget pi ;

   MobileApp ac("Alarm Clock") ;

   MobileApp it("International time");

   SystemWidget tds;

   //adding elements to the screen
   launch.add_element(gm,1,1);

   launch.add_element(s,5,5);

   Folder foldd(launch); //takes the elements of launch that have been added until this moment

   launch.add_element(foldd,4,2);

   launch.add_element(abr,3,3);

   launch.add_element(pi,5,3);

   launch.add_element(pi,6,1);

   launch.add_element(f,2,5);

   launch.add_element(cb,4,5);

   cout<<launch; //prints the screen with all added elements

   launch.remove_element(1,1); //removing google maps

   launch.move_element(4,5,3,3); //moving elements

   cout<<launch; //prints screen after manipulations

   launch.clear();
   cout<<launch; //prints the screen after clearing- empty screen

return 0;
}
