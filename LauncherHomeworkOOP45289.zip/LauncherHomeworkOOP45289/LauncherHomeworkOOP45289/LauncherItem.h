#ifndef LAUNCHERITEM_H
#define LAUNCHERITEM_H

using namespace std;
#include <iostream>
class LauncherItem
{
    public:

        /** boolean function that returns if the object is movable*/
        virtual bool canMove() const=0;

        /** Access title
         * \return The current value of title
         */
        char* Get_title() const { return title; }

        /** Set title
         * \param val New value to set
         */
       virtual void Set_title(char*)=0;

       /** deletes title*/
       void deleteTitle()
       {
       if(title!=NULL){delete[] title;
       title=NULL;}
       }

    protected:
        char* title; //!< Member variable "title"
};

#endif // LAUNCHERITEM_H
