#ifndef FOLDER_H
#define FOLDER_H

#include "LauncherItem.h"
#include "Launcher.h"


class Folder : public LauncherItem
{
public:
    /** Default constructor */
    Folder();

    /**Constructor with parameters*/
    Folder(LauncherItem*** items,bool** is_taken,int length,int width);

    /**Constructor with parameters for an empty folder*/
    Folder(int length,int width);

    /** Constructor with parameters
    *identical as idea as the first constructor with parameters
     */
    Folder(const Launcher& launcher);

    /** Default destructor */
    virtual ~Folder();

    /** Copy constructor
     *  \param other Object to copy from
     */
    Folder(const Folder& other);

    /** Assignment operator
     *  \param other Object to assign from
     *  \return A reference to this
     */

    Folder& operator=(const Folder& other);

    /** boolean function that returns if the object is movable*/
    bool canMove() const
    {
        return true;
    }

    /**sets the name of the folder- concatenation of all the element names */
    void Set_title();

    /**sets the default title- "Empty folder" */
    void Set_title(char*);

    /**adds element to the launcher*/
    void add_element(LauncherItem& item,int length,int width);

    /**removes element from the screen*/
    void remove_element(int length,int width);

    /**clears the screen from all elements*/
    void clear();

    /** copies all the items to this launcher */
    void copy_items(LauncherItem*** items,bool** is_taken,int length,int width) ;

protected:

private:
    Launcher* launch; /**all the elements in the folder*/
};

#endif // FOLDER_H
